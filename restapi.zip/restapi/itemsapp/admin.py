from django.contrib import admin
from .models import ItemModel

# Register your models here.
admin.site.register(ItemModel)