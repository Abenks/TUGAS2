"""kelas URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import path
from django.http import HttpResponse
from dashboard.views import *

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',home, name='Home'),
    path('about/',about, name='About'),
    path('contact/',contact, name='Contact'),
    path('login/',login, name='Login'),
    path('addbrg/',Barang_Add,name='addbrg'),
    path('addmember/',Member_Add,name='addmember'),
    path('vbrg/',Barang_View, name='vbrg'),
    path('vmember/',Member_View, name='vmember'),
    path('ubah/<int:id_barang>',ubah_brg,name='ubah_brg'),
    path('ubahm/<int:id_member>',ubah_member,name='ubah_member'),
    path('hapus/<int:id_barang>',hapus_brg,name='hapus_brg'),
    path('hapusm/<int:id_member>',hapus_member,name='hapus_member'),

]
