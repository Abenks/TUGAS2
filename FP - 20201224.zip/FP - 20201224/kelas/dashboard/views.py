from django.shortcuts import render, redirect
from dashboard.forms import FormBarang, FormmMember
from dashboard.models import Barang, Member
from django.contrib import messages
from dashboard.views import *

def hapus_brg(request,id_barang):
    barangs=Barang.objects.filter(id=id_barang)
    barangs.delete()
    messages.success(request, "Data Terhapus")
    return redirect('vbrg')

def hapus_member(request,id_member):
    members=Member.objects.filter(id=id_member)
    members.delete()
    messages.success(request, "Data Terhapus")
    return redirect('vmember')

def ubah_brg(request,id_barang):
    barangs=Barang.objects.get(id=id_barang)
    if request.POST:
        form=FormBarang(request.POST,instance=barangs)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Berhasil Diubah")
            return redirect('ubah_brg',id_barang=id_barang)
    else:
        form=FormBarang(instance=barangs)
        konteks = {
            'form':form,
            'barangs':barangs
        }
    return render(request,'ubah_brg.html',konteks)

def ubah_member(request,id_member):
    members=Member.objects.get(id=id_member)
    if request.POST:
        form=FormmMember(request.POST,instance=members)
        if form.is_valid():
            form.save()
            messages.success(request, "Data Berhasil Diubah")
            return redirect('ubah_member',id_member=id_member)
    else:
        form=FormmMember(instance=members)
        konteks = {
            'form':form,
            'members':members
        }
    return render(request,'ubah_member.html',konteks)

def Barang_Add(request):
    if request.POST:
        form= FormBarang(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Berhasil Ditambahkan")
            form = FormBarang()
            konteks = {
                'form':form,
            }
            return render(request,'tambah_barang.html',konteks)
    else:
        form=FormBarang()
        konteks = {
            'form': form,
        }
    return render(request,'tambah_barang.html',konteks)

def Member_Add(request):
    if request.POST:
        form= FormmMember(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Berhasil Ditambahkan")
            form = FormmMember()
            konteks = {
                'form':form,
            }
            return render(request,'tambah_member.html',konteks)
    else:
        form=FormmMember()
        konteks = {
            'form': form,
        }
    return render(request,'tambah_member.html',konteks)

def Barang_View(request):
    barangs=Barang.objects.all()
    konteks={
        'barangs':barangs,
    }
    return render(request,'tampil_brg.html',konteks)

def Member_View(request):
    members=Member.objects.all()
    konteks={
        'members':members,
    }
    return render(request,'tampil_member.html',konteks)

def tambah_barang(request):
    form = FormBarang()
    konteks = {
        'form':form, 
    }
    return render(request, 'tambah_barang.html',konteks) 

def tambah_member(request):
    form = FormmMember()
    konteks = {
        'form':form, 
    }
    return render(request, 'tambah_member.html',konteks) 

def home(request):
    titelnya='Home'
    konteks = {
        'titel':titelnya,
    } 
    return render(request,'home.html',konteks)

def about(request):
    titelnya='About'
    konteks = {
        'titel':titelnya,
    } 
    return render(request,'about.html',konteks)

def contact(request):
    titelnya='Contact'
    konteks = {
        'titel':titelnya,
    } 
    return render(request,'contact.html',konteks) 

def login(request):
    titelnya='Login'
    konteks = {
        'titel':titelnya,
    } 
    return render(request,'login.html',konteks) 