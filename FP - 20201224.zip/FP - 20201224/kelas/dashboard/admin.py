from django.contrib import admin
from .models import Barang, Jenis, Member

admin.site.register(Barang)
admin.site.register(Jenis)

class kolomBarang(admin.ModelAdmin):
    list_display = ['kodebrg', 'nama', 'stok', 'harga', 'link_brg', 'jenis_id']
    search_fields = ['kodebrg', 'nama']
    list_filter = ('jenis_id')
    list_per_page = 3

class kolomMember(admin.ModelAdmin):
    list_display = ['kode_member', 'nama', 'alamat', 'tgl_gabung', 'point']
    search_fields = ['kode_member', 'nama']
    list_filter = ('point',)
    list_per_page = 3

admin.site.register(Member, kolomMember)