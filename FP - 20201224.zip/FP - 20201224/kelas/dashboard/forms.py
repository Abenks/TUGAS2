from django.forms import ModelForm
from dashboard.models import Barang, Member
from django import forms

class FormBarang(ModelForm):
    class Meta:
        model = Barang
        fields = '__all__'   

        widgets = {
            'kodebrg':forms.TextInput({'class':'form-control'}),
            'nama':forms.TextInput({'class':'form-control'}),
            'stok':forms.NumberInput({'class':'form-control'}),
            'harga':forms.NumberInput({'class':'form-control'}),
            'link_gbr':forms.TextInput({'class':'form-control'}),
        }

class FormmMember(ModelForm):
    class Meta:
        model = Member
        fields = '__all__'   

        widgets = {
            'kode_member':forms.TextInput({'class':'form-control'}),
            'nama':forms.TextInput({'class':'form-control'}),
            'alamat':forms.TextInput({'class':'form-control'}),
            'tgl_gabung':forms.DateInput({'class':'form-control','type':'date'}),
            'point':forms.NumberInput({'class':'form-control'}),
        }        